# 🌸 治愈下载器 (Healing Downloader)

一个充满温暖与治愈感的现代化视频音频下载应用，采用 Flutter Web 构建，具有优雅的用户界面和丝滑的交互体验。

![治愈下载器预览](https://img.shields.io/badge/Flutter-3.32.5-blue) ![Web支持](https://img.shields.io/badge/Platform-Web-green) ![治愈系设计](https://img.shields.io/badge/Design-Healing-pink)

## ✨ 特色功能

### 🎨 治愈系设计语言
- **温暖配色方案**: 薄荷绿 + 淡雅紫 + 温暖米色的治愈系配色
- **圆润亲和**: 28px 大圆角设计，温柔不刺眼
- **柔和阴影**: 多层次渐变阴影，营造立体而不突兀的视觉效果
- **智能响应**: 自动适配深色/浅色模式，跟随系统设置

### 🌊 丝滑交互体验
- **弹性动画**: 采用 `easeOutCubic` 自然曲线，模拟真实物理效果
- **微妙浮动**: 6秒缓慢呼吸式浮动，如云朵般轻盈
- **焦点反馈**: 输入框聚焦时的柔和缩放和发光效果
- **按钮脉冲**: 2秒心跳式呼吸动画，充满生命力
- **星光闪烁**: 背景星星的温柔闪烁，增添梦幻感

### 🌟 治愈背景特效
- **薄荷光球**: 慢速浮动的治愈色彩光球
- **温暖渐变**: 从米白到纯白的柔和背景过渡
- **星光点缀**: 随机分布的闪烁星光
- **30秒循环**: 超慢速背景动画，避免视觉疲劳

### 💫 温暖亲和力元素
- **暖心文案**: "开始治愈之旅"、"温柔下载"等贴心提示
- **友好图标**: 爱心、星星、云朵等可爱元素
- **智能提示**: 温暖的错误提示和成功反馈
- **情感连接**: "用心制作"、"自然流畅"的情感标签

## 🎯 核心功能

- **🎵 音频下载**: 支持多种音频格式 (MP3, M4A, WAV, 原始格式)
- **🎬 视频下载**: 支持多种视频格式和质量选择
- **⚡ 双引擎**: yt-dlp 内置优化版 + aria2c 外部加速器
- **📊 实时进度**: WebSocket 实时进度显示和状态更新
- **🌐 广泛支持**: 支持 600+ 视频网站
- **📱 响应式**: 完美适配桌面和移动端

## 🏗️ 项目架构

### 📁 目录结构
```
frontend/
├── lib/
│   ├── main.dart                           # 应用入口 (41行)
│   ├── controllers/
│   │   └── download_controller.dart        # 状态管理和业务逻辑
│   ├── screens/
│   │   └── home_screen.dart               # 主界面屏幕
│   ├── widgets/                           # 可复用UI组件
│   │   ├── healing_header.dart            # 治愈系头部组件
│   │   ├── healing_url_input.dart         # 智能URL输入框
│   │   └── healing_download_button.dart   # 动感下载按钮
│   ├── painters/
│   │   └── healing_background_painter.dart # 自定义背景绘制
│   ├── themes/
│   │   └── app_theme.dart                 # 治愈系主题配置
│   └── models/
│       └── orb_data.dart                  # 光球数据模型
├── pubspec.yaml                           # 依赖配置
├── web/                                   # Web资源文件
└── build/web/                            # 构建输出目录
```

### 🎨 设计系统

#### 配色方案
```dart
// 治愈系主色调
static const Color healingMint = Color(0xFFB8E6B8);      // 薄荷绿
static const Color softLavender = Color(0xFFE8D5E8);     // 淡雅紫
static const Color warmCream = Color(0xFFFAF7F0);        // 温暖米
static const Color gentlePeach = Color(0xFFFFE5CC);      // 温柔桃
static const Color tranquilBlue = Color(0xFFD6EAF8);     // 宁静蓝
static const Color rosyBlush = Color(0xFFFDE2E7);        // 玫瑰腮红

// 功能性颜色
static const Color primaryMint = Color(0xFF7FB069);       // 主要操作
static const Color secondaryLavender = Color(0xFFA855F7); // 次要操作
static const Color accentPeach = Color(0xFFFF8A65);      // 强调色
static const Color neutralWarm = Color(0xFF8B7355);      // 中性色
```

#### 动画曲线
- **进入动画**: `Curves.easeOutCubic` - 自然物理效果
- **浮动动画**: `Curves.easeInOut` - 平滑呼吸效果
- **弹性动画**: `Curves.elasticOut` - 生动的弹性反馈
- **交互动画**: `Curves.easeInOut` - 流畅的状态转换

### 🔧 技术栈

#### 前端框架
- **Flutter 3.32.5**: Google的现代UI框架
- **Dart 3.8.1**: 高性能编程语言
- **Web平台**: 编译为高效的JavaScript

#### 核心依赖
```yaml
dependencies:
  flutter: sdk
  provider: ^6.1.1              # 状态管理
  http: ^1.1.0                  # HTTP请求
  socket_io_client: ^2.0.3+1    # WebSocket通信
  flutter_animate: ^4.2.0+1     # 动画库
  google_fonts: ^6.1.0          # 字体库
  shimmer: ^3.0.0               # 闪光效果
```

#### 字体系统
- **Nunito**: 主要字体，圆润亲和，适合治愈系设计
- **Material Icons**: 系统图标，现代化设计语言
- **Cupertino Icons**: 补充图标，iOS风格元素

## 🚀 快速开始

### 环境要求

#### 必需软件
- **Flutter SDK**: >= 3.0.0
- **Dart SDK**: >= 3.0.0
- **Web浏览器**: Chrome/Edge/Firefox/Safari
- **Python**: >= 3.6 (用于开发服务器)

#### 开发工具 (推荐)
- **VS Code**: 配合Flutter扩展
- **Android Studio**: 完整的Flutter IDE
- **IntelliJ IDEA**: JetBrains系列IDE

### 🛠️ 安装部署

#### 1. 克隆项目
```bash
git clone <repository-url>
cd yt-whisper/frontend
```

#### 2. 安装依赖
```bash
# 安装Flutter依赖
flutter pub get

# 检查Flutter环境
flutter doctor

# 验证Web支持
flutter devices
```

#### 3. 开发模式运行
```bash
# 方式一：Flutter开发服务器 (推荐开发时使用)
flutter run -d web-server --web-hostname 0.0.0.0 --web-port 8080

# 方式二：Chrome浏览器模式 (支持热重载调试)
flutter run -d chrome --web-port 8080
```

#### 4. 生产环境部署
```bash
# 构建Web版本
flutter build web

# 启动生产服务器
cd build/web
python3 -m http.server 8080 --bind 0.0.0.0

# 或使用Node.js服务器
npx http-server -p 8080 -a 0.0.0.0

# 或使用Nginx部署 (推荐生产环境)
# 将build/web/目录内容复制到Nginx web根目录
```

### 🌐 访问应用

#### 本地访问
- **开发模式**: http://localhost:8080
- **局域网访问**: http://[your-ip]:8080

#### WSL用户 (Windows)
如果在WSL中运行，Windows中访问：
```bash
# 查看WSL IP地址
hostname -I
# 例如：http://172.21.211.234:8080
```

#### Docker部署 (可选)
```dockerfile
# Dockerfile
FROM nginx:alpine
COPY build/web /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

```bash
# 构建和运行
docker build -t healing-downloader .
docker run -p 8080:80 healing-downloader
```

## 🔌 后端集成

### API接口配置
在 `lib/controllers/download_controller.dart` 中配置后端地址：

```dart
class DownloadController extends ChangeNotifier {
  // 修改为你的后端API地址
  static const String apiBase = 'http://your-backend-api:8000';
}
```

### 必需的后端接口

#### 1. 下载状态检查
```http
GET /api/test-aria2c
Response: {
  "status": "working|not_found|available_but_not_used",
  "message": "状态描述"
}
```

#### 2. 启动下载
```http
POST /api/download
Content-Type: application/json

{
  "type": "audio|video",
  "url": "视频URL",
  "session_id": "会话ID",
  "downloader": "ytdlp|aria2c",
  "audio_format": "original|mp3|m4a|wav",
  "video_format": "original|mp4|mkv|avi",
  "audio_quality": "192|128|256|320|0",
  "video_quality": "720p|480p|best"
}
```

#### 3. 文件列表
```http
GET /api/downloads
Response: [
  {
    "name": "文件名",
    "size_formatted": "文件大小",
    "modified": "修改时间",
    "download_url": "下载链接"
  }
]
```

#### 4. WebSocket进度推送
```javascript
// 连接WebSocket
socket.emit('join_session', { session_id: 'session_id' });

// 接收进度更新
socket.on('download_progress', {
  status: 'downloading|finished|error',
  percentage: 85.5,
  title: '视频标题',
  downloaded: '12.5 MB',
  speed: '1.2 MB/s',
  eta: '00:30'
});
```

## 🎨 自定义主题

### 修改配色方案
在 `lib/themes/app_theme.dart` 中自定义颜色：

```dart
class AppTheme {
  // 修改主色调
  static const Color primaryMint = Color(0xFF你的颜色);
  static const Color secondaryLavender = Color(0xFF你的颜色);
  
  // 添加自定义渐变
  static const LinearGradient customGradient = LinearGradient(
    colors: [Color(0xFF颜色1), Color(0xFF颜色2)],
  );
}
```

### 调整动画效果
在组件中修改动画参数：

```dart
// 修改动画时长
.animate()
.slideY(
  begin: -0.15,
  duration: 800.ms,        // 修改这里
  curve: Curves.easeOutCubic // 修改曲线
)
.fadeIn()
```

### 自定义背景效果
在 `lib/painters/healing_background_painter.dart` 中：

```dart
// 修改光球数量和颜色
final orbs = [
  OrbData(
    // 调整位置、大小、颜色
    radius: 80,  // 光球大小
    color: yourCustomColor.withOpacity(0.15),
  ),
];
```

## 📊 性能优化

### 构建优化
```bash
# 启用树摇(Tree Shaking)减小包体积
flutter build web --tree-shake-icons

# 启用代码分割
flutter build web --split-debug-info=build/web/debug_symbols

# 压缩构建
flutter build web --release
```

### 运行时优化
- **字体优化**: 使用 Google Fonts 的字体子集
- **图标优化**: 自动树摇移除未使用图标
- **动画优化**: 使用硬件加速的 Transform 动画
- **内存管理**: 及时释放动画控制器和资源

## 🧪 测试

### 运行测试
```bash
# 单元测试
flutter test

# 集成测试
flutter test integration_test/

# Web兼容性测试
flutter test --platform chrome
```

### 测试覆盖率
```bash
# 生成覆盖率报告
flutter test --coverage
genhtml coverage/lcov.info -o coverage/html
```

## 🛠️ 故障排除

### 常见问题

#### 1. Flutter Web构建失败
```bash
# 清理缓存
flutter clean
flutter pub get

# 更新Flutter
flutter upgrade
```

#### 2. 字体加载问题
```bash
# 检查网络连接
# Google Fonts需要网络访问
```

#### 3. 动画性能问题
```dart
// 在低性能设备上禁用复杂动画
if (MediaQuery.of(context).disableAnimations) {
  return 静态组件;
}
```

#### 4. WebSocket连接失败
```dart
// 检查后端CORS配置
// 确保WebSocket端口开放
```

### 性能监控
```dart
// 启用性能监控
import 'package:flutter/rendering.dart';

void main() {
  debugPaintSizeEnabled = false; // 调试模式显示组件边界
  runApp(MyApp());
}
```

## 📈 版本历史

### v2.0.0 (治愈系重构版) - 当前版本
- 🎨 全新治愈系设计语言
- 🏗️ 代码重构为模块化架构 (从2035行拆分为8个模块)
- 🌊 增强动画和交互体验
- 📱 改进响应式设计
- 🔧 优化性能和稳定性
- 🌸 温暖亲和力的用户体验
- ✨ 丝滑的微交互动画

### v1.0.0 (初始版本)
- 📦 基础下载功能
- 🎵 音频/视频下载支持
- 🔗 多网站兼容
- 📊 实时进度显示

## 🤝 贡献指南

### 开发流程
1. Fork 项目仓库
2. 创建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 创建 Pull Request

### 代码规范
- 使用 `dart format` 格式化代码
- 遵循 Flutter 官方代码规范
- 添加必要的注释和文档
- 确保所有测试通过

### 设计原则
- **治愈优先**: 所有设计决策以用户感受为中心
- **温暖亲和**: 界面元素应传达温暖和友好
- **自然流畅**: 动画和交互应模拟真实物理世界
- **简约优雅**: 避免过度设计，保持简洁美感

## 📄 开源协议

本项目基于 MIT 协议开源 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 🙏 致谢

- **Flutter团队**: 提供了优秀的跨平台框架
- **Google Fonts**: 提供了美观的开源字体
- **yt-dlp项目**: 强大的视频下载核心
- **设计灵感**: 来自日本的治愈系美学文化
- **开源社区**: 提供了丰富的包和工具

## 📞 联系我们

- **问题反馈**: [GitHub Issues](https://github.com/your-repo/issues)
- **功能建议**: [GitHub Discussions](https://github.com/your-repo/discussions)
- **技术交流**: [项目Wiki](https://github.com/your-repo/wiki)

---

<div align="center">

**🌸 用心制作，温暖相伴 🌸**

*Made with ❤️ by the Healing Team*

**当前运行地址**: http://172.21.211.234:8080

</div>