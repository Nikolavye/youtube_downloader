import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:socket_io_client/socket_io_client.dart' as io;

class DownloadController extends ChangeNotifier {
  // API配置
  static const String apiBase = 'http://172.21.211.234:8000';
  
  // Socket连接
  io.Socket? socket;
  
  // 状态管理
  bool _isLoading = false;
  String? _currentSessionId;
  Map<String, dynamic>? _currentProgress;
  String _downloaderType = 'ytdlp';
  String _downloadType = 'audio';
  String _audioFormat = 'original';
  String _videoFormat = 'original';
  String _videoQuality = '720p';
  String _audioQuality = '192';
  bool _embedMetadata = false;
  bool _embedThumbnail = false;
  String _downloaderStatus = '正在检测下载器状态...';
  List<Map<String, dynamic>> _downloadFiles = [];
  String _fileFilter = 'all';
  
  // Getters
  bool get isLoading => _isLoading;
  String? get currentSessionId => _currentSessionId;
  Map<String, dynamic>? get currentProgress => _currentProgress;
  String get downloaderType => _downloaderType;
  String get downloadType => _downloadType;
  String get audioFormat => _audioFormat;
  String get videoFormat => _videoFormat;
  String get videoQuality => _videoQuality;
  String get audioQuality => _audioQuality;
  bool get embedMetadata => _embedMetadata;
  bool get embedThumbnail => _embedThumbnail;
  String get downloaderStatus => _downloaderStatus;
  List<Map<String, dynamic>> get downloadFiles => _downloadFiles;
  String get fileFilter => _fileFilter;
  
  void setLoading(bool value) {
    _isLoading = value;
    notifyListeners();
  }
  
  void setDownloaderType(String type) {
    _downloaderType = type;
    notifyListeners();
  }
  
  void setDownloadType(String type) {
    _downloadType = type;
    notifyListeners();
  }
  
  void setAudioFormat(String format) {
    _audioFormat = format;
    notifyListeners();
  }
  
  void setVideoFormat(String format) {
    _videoFormat = format;
    notifyListeners();
  }
  
  void setVideoQuality(String quality) {
    _videoQuality = quality;
    notifyListeners();
  }
  
  void setAudioQuality(String quality) {
    _audioQuality = quality;
    notifyListeners();
  }
  
  void setEmbedMetadata(bool value) {
    _embedMetadata = value;
    notifyListeners();
  }
  
  void setEmbedThumbnail(bool value) {
    _embedThumbnail = value;
    notifyListeners();
  }
  
  void setDownloaderStatus(String status) {
    _downloaderStatus = status;
    notifyListeners();
  }
  
  void setFileFilter(String filter) {
    _fileFilter = filter;
    notifyListeners();
  }
  
  void setCurrentProgress(Map<String, dynamic>? progress) {
    _currentProgress = progress;
    notifyListeners();
  }
  
  void setDownloadFiles(List<Map<String, dynamic>> files) {
    _downloadFiles = files;
    notifyListeners();
  }
  
  void initSocket() {
    _currentSessionId = 'session_${DateTime.now().millisecondsSinceEpoch}_${(DateTime.now().microsecond % 1000).toString().padLeft(3, '0')}';
    
    socket = io.io(apiBase, <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': false,
    });
    
    socket!.connect();
    
    socket!.on('connected', (data) {
      debugPrint('Socket connected: $data');
    });
    
    socket!.on('download_progress', (data) {
      setCurrentProgress(data);
      if (data['status'] == 'finished' || data['status'] == 'error') {
        setLoading(false);
        loadFiles();
      }
    });
  }
  
  Future<void> loadFiles() async {
    try {
      final response = await http.get(Uri.parse('$apiBase/api/downloads'));
      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        setDownloadFiles(data.cast<Map<String, dynamic>>());
      }
    } catch (e) {
      debugPrint('加载文件列表失败: $e');
    }
  }
  
  Future<void> checkDownloaderStatus() async {
    try {
      final response = await http.get(Uri.parse('$apiBase/api/test-aria2c'));
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        String statusText = '';
        
        if (data['status'] == 'not_found') {
          statusText = '❌ aria2c未安装，仅可使用yt-dlp内置下载器';
        } else if (data['status'] == 'available_but_not_used' || data['status'] == 'working') {
          statusText = '✅ 两种下载器均可用，请选择您偏好的下载器';
        } else {
          statusText = '⚠️ aria2c状态异常，建议使用yt-dlp内置下载器';
        }
        
        setDownloaderStatus(statusText);
      }
    } catch (error) {
      setDownloaderStatus('⚠️ 下载器状态检测失败: $error');
    }
  }
  
  Future<Map<String, dynamic>> startDownload(String url) async {
    setLoading(true);
    
    final options = {
      'type': _downloadType,
      'url': url,
      'session_id': _currentSessionId,
      'downloader': _downloaderType,
    };
    
    if (_downloadType == 'video') {
      options['video_quality'] = _videoQuality;
      options['video_format'] = _videoFormat;
    } else {
      options['audio_format'] = _audioFormat;
      if (_audioFormat != 'original') {
        options['audio_quality'] = _audioQuality;
        options['embed_metadata'] = _embedMetadata.toString();
        options['embed_thumbnail'] = _embedThumbnail.toString();
      }
    }
    
    try {
      final response = await http.post(
        Uri.parse('$apiBase/api/download'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(options),
      );
      
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        socket!.emit('join_session', {'session_id': _currentSessionId});
        return {'success': true, 'data': data};
      } else {
        setLoading(false);
        final error = json.decode(response.body)['error'];
        return {'success': false, 'error': error};
      }
    } catch (e) {
      setLoading(false);
      return {'success': false, 'error': '下载请求失败: $e'};
    }
  }
  
  @override
  void dispose() {
    socket?.disconnect();
    super.dispose();
  }
}