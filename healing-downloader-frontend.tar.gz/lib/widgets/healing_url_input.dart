import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../themes/app_theme.dart';

class HealingUrlInput extends StatefulWidget {
  final TextEditingController controller;
  final VoidCallback? onSubmit;
  
  const HealingUrlInput({
    super.key,
    required this.controller,
    this.onSubmit,
  });

  @override
  State<HealingUrlInput> createState() => _HealingUrlInputState();
}

class _HealingUrlInputState extends State<HealingUrlInput>
    with SingleTickerProviderStateMixin {
  late AnimationController _focusController;
  late Animation<double> _focusAnimation;
  bool _isFocused = false;

  @override
  void initState() {
    super.initState();
    _focusController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _focusAnimation = Tween<double>(
      begin: 1.0,
      end: 1.02,
    ).animate(CurvedAnimation(
      parent: _focusController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _focusController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return AnimatedBuilder(
      animation: _focusAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: _focusAnimation.value,
          child: Container(
            decoration: BoxDecoration(
              gradient: isDark 
                ? LinearGradient(
                    colors: [
                      AppTheme.darkSurface.withOpacity(0.8),
                      AppTheme.darkSurface.withOpacity(0.6),
                    ],
                  )
                : const LinearGradient(
                    colors: [
                      Colors.white,
                      Color(0xFFFFFBF7),
                    ],
                  ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _isFocused 
                  ? AppTheme.primaryMint.withOpacity(0.5)
                  : (isDark 
                      ? Colors.white.withOpacity(0.08)
                      : AppTheme.primaryMint.withOpacity(0.1)),
                width: _isFocused ? 2 : 1,
              ),
              boxShadow: _isFocused 
                ? AppTheme.glowShadow
                : (isDark 
                    ? []
                    : AppTheme.softShadow),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 4),
              child: Row(
                children: [
                  // 可爱的前缀图标
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      gradient: _isFocused 
                        ? AppTheme.mintGradient
                        : LinearGradient(
                            colors: [
                              AppTheme.primaryMint.withOpacity(0.2),
                              AppTheme.primaryMint.withOpacity(0.1),
                            ],
                          ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      Icons.link_rounded,
                      color: _isFocused 
                        ? Colors.white
                        : AppTheme.primaryMint,
                      size: 22,
                    ),
                  ).animate(target: _isFocused ? 1 : 0)
                    .rotate(end: 0.05)
                    .scale(end: const Offset(1.1, 1.1)),
                  
                  const SizedBox(width: 16),
                  
                  // 输入框
                  Expanded(
                    child: TextField(
                      controller: widget.controller,
                      onSubmitted: (_) => widget.onSubmit?.call(),
                      style: GoogleFonts.nunito(
                        fontSize: 17,
                        color: colorScheme.onSurface,
                        fontWeight: FontWeight.w500,
                        letterSpacing: 0.2,
                      ),
                      decoration: InputDecoration(
                        hintText: '请输入视频链接，开始治愈之旅...',
                        hintStyle: GoogleFonts.nunito(
                          fontSize: 17,
                          color: colorScheme.onSurfaceVariant.withOpacity(0.6),
                          fontWeight: FontWeight.w400,
                        ),
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onTap: () {
                        setState(() {
                          _isFocused = true;
                        });
                        _focusController.forward();
                      },
                      onTapOutside: (_) {
                        setState(() {
                          _isFocused = false;
                        });
                        _focusController.reverse();
                      },
                    ),
                  ),
                  
                  // 提交按钮
                  if (widget.controller.text.isNotEmpty)
                    GestureDetector(
                      onTap: widget.onSubmit,
                      child: Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          gradient: AppTheme.mintGradient,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(
                              color: AppTheme.primaryMint.withOpacity(0.3),
                              blurRadius: 12,
                              offset: const Offset(0, 4),
                            ),
                          ],
                        ),
                        child: const Icon(
                          Icons.arrow_forward_rounded,
                          color: Colors.white,
                          size: 20,
                        ),
                      ).animate()
                        .scale(begin: const Offset(0.8, 0.8))
                        .fadeIn(),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    ).animate()
      .slideX(begin: -0.1, duration: 500.ms, curve: Curves.easeOutCubic);
  }
}