import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:shimmer/shimmer.dart';
import '../themes/app_theme.dart';

class HealingDownloadButton extends StatefulWidget {
  final bool isLoading;
  final String downloadType;
  final VoidCallback? onPressed;

  const HealingDownloadButton({
    super.key,
    required this.isLoading,
    required this.downloadType,
    this.onPressed,
  });

  @override
  State<HealingDownloadButton> createState() => _HealingDownloadButtonState();
}

class _HealingDownloadButtonState extends State<HealingDownloadButton>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _pressController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _pressAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat();

    _pressController = AnimationController(
      duration: const Duration(milliseconds: 150),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(
      begin: 1.0,
      end: 1.05,
    ).animate(CurvedAnimation(
      parent: _pulseController,
      curve: Curves.easeInOut,
    ));

    _pressAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(
      parent: _pressController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _pressController.dispose();
    super.dispose();
  }

  void _onTapDown(TapDownDetails details) {
    _pressController.forward();
  }

  void _onTapUp(TapUpDetails details) {
    _pressController.reverse();
  }

  void _onTapCancel() {
    _pressController.reverse();
  }

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    String buttonText;
    String emoji;
    LinearGradient gradient;

    if (widget.isLoading) {
      emoji = widget.downloadType == 'video' ? '🎬' : '🎵';
      buttonText = widget.downloadType == 'video' ? '正在温柔下载视频...' : '正在治愈下载音频...';
      gradient = LinearGradient(
        colors: [
          Colors.grey.withOpacity(0.6),
          Colors.grey.withOpacity(0.4),
        ],
      );
    } else {
      emoji = widget.downloadType == 'video' ? '🎬' : '🎵';
      buttonText = widget.downloadType == 'video' ? '治愈下载视频' : '温柔获取音频';
      gradient = widget.downloadType == 'video' 
        ? AppTheme.lavenderGradient
        : AppTheme.mintGradient;
    }

    return AnimatedBuilder(
      animation: Listenable.merge([_pulseAnimation, _pressAnimation]),
      builder: (context, child) {
        return Transform.scale(
          scale: widget.isLoading 
            ? 1.0 
            : _pulseAnimation.value * _pressAnimation.value,
          child: GestureDetector(
            onTapDown: widget.isLoading ? null : _onTapDown,
            onTapUp: widget.isLoading ? null : _onTapUp,
            onTapCancel: widget.isLoading ? null : _onTapCancel,
            onTap: widget.isLoading ? null : widget.onPressed,
            child: Container(
              width: double.infinity,
              height: 64,
              decoration: BoxDecoration(
                gradient: gradient,
                borderRadius: BorderRadius.circular(20),
                boxShadow: widget.isLoading 
                  ? []
                  : [
                      BoxShadow(
                        color: (widget.downloadType == 'video' 
                          ? AppTheme.secondaryLavender
                          : AppTheme.primaryMint).withOpacity(0.4),
                        blurRadius: 20,
                        offset: const Offset(0, 8),
                      ),
                      BoxShadow(
                        color: Colors.white.withOpacity(0.2),
                        blurRadius: 10,
                        offset: const Offset(0, -2),
                      ),
                    ],
              ),
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: Colors.white.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (widget.isLoading) ...[
                      Shimmer.fromColors(
                        baseColor: Colors.white.withOpacity(0.6),
                        highlightColor: Colors.white,
                        child: Container(
                          width: 24,
                          height: 24,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const CircularProgressIndicator(
                            strokeWidth: 2.5,
                            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                    ] else ...[
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(
                          child: Text(
                            emoji,
                            style: const TextStyle(fontSize: 18),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                    ],
                    
                    Flexible(
                      child: Text(
                        buttonText,
                        style: GoogleFonts.nunito(
                          fontSize: 18,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                          letterSpacing: 0.3,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    
                    if (!widget.isLoading) ...[
                      const SizedBox(width: 12),
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.download_rounded,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
        );
      },
    ).animate()
      .scale(begin: const Offset(0.9, 0.9), duration: 600.ms, curve: Curves.elasticOut);
  }
}