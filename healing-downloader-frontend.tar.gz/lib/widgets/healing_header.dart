import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../themes/app_theme.dart';

class HealingHeader extends StatelessWidget {
  const HealingHeader({super.key});

  @override
  Widget build(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        gradient: isDark 
          ? LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppTheme.darkSurface.withOpacity(0.8),
                AppTheme.darkSurface.withOpacity(0.6),
              ],
            )
          : const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white,
                Color(0xFFFFFBF7),
              ],
            ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: isDark 
            ? Colors.white.withOpacity(0.08)
            : AppTheme.primaryMint.withOpacity(0.1),
          width: 1,
        ),
        boxShadow: isDark 
          ? [
              BoxShadow(
                color: Colors.black.withOpacity(0.2),
                blurRadius: 32,
                offset: const Offset(0, 12),
              ),
            ]
          : AppTheme.softShadow,
      ),
      child: Column(
        children: [
          // 可爱的图标组合
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              gradient: AppTheme.mintGradient,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.primaryMint.withOpacity(0.3),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: const Icon(
              Icons.cloud_download_rounded,
              size: 40,
              color: Colors.white,
            ),
          ).animate()
            .scale(begin: const Offset(0.8, 0.8), duration: 800.ms, curve: Curves.elasticOut)
            .then()
            .shimmer(duration: 2000.ms, color: Colors.white.withOpacity(0.5)),
          
          const SizedBox(height: 20),
          
          // 治愈系标题
          Text(
            '🌸 治愈下载器',
            style: GoogleFonts.nunito(
              fontSize: 32,
              fontWeight: FontWeight.w800,
              color: colorScheme.onSurface,
              letterSpacing: -0.5,
              height: 1.2,
            ),
            textAlign: TextAlign.center,
          ).animate()
            .slideY(begin: 0.3, duration: 600.ms, curve: Curves.easeOutCubic)
            .fadeIn(),
          
          const SizedBox(height: 12),
          
          // 温暖的副标题
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(
              color: isDark 
                ? AppTheme.primaryMint.withOpacity(0.1)
                : AppTheme.healingMint.withOpacity(0.3),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: AppTheme.primaryMint.withOpacity(0.2),
                width: 1,
              ),
            ),
            child: Text(
              '✨ 温柔下载 • 治愈体验 • 600+网站支持',
              style: GoogleFonts.nunito(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: isDark 
                  ? AppTheme.primaryMint.withOpacity(0.9)
                  : AppTheme.neutralWarm,
                letterSpacing: 0.2,
              ),
              textAlign: TextAlign.center,
            ),
          ).animate()
            .slideY(begin: 0.2, duration: 700.ms, delay: 200.ms, curve: Curves.easeOutCubic)
            .fadeIn(),
          
          const SizedBox(height: 16),
          
          // 情感连接的小提示
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.rosyBlush.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.favorite_rounded,
                      size: 16,
                      color: Color(0xFFE91E63),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '用心制作',
                      style: GoogleFonts.nunito(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFFE91E63),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.tranquilBlue.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.auto_awesome_rounded,
                      size: 16,
                      color: Color(0xFF2196F3),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      '自然流畅',
                      style: GoogleFonts.nunito(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: const Color(0xFF2196F3),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ).animate()
            .slideY(begin: 0.1, duration: 800.ms, delay: 400.ms, curve: Curves.easeOutCubic)
            .fadeIn(),
        ],
      ),
    );
  }
}