import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';

import 'controllers/download_controller.dart';
import 'screens/home_screen.dart';
import 'themes/app_theme.dart';

void main() {
  // 初始化动画库
  Animate.restartOnHotReload = true;
  
  runApp(const HealingDownloaderApp());
}

class HealingDownloaderApp extends StatelessWidget {
  const HealingDownloaderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => DownloadController(),
      child: MaterialApp(
        title: '🌸 治愈下载器',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.buildLightTheme(),
        darkTheme: AppTheme.buildDarkTheme(),
        themeMode: ThemeMode.system,
        home: const HomeScreen(),
        builder: (context, child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(
              textScaler: const TextScaler.linear(1.0), // 防止系统字体缩放影响设计
            ),
            child: child!,
          );
        },
      ),
    );
  }
}