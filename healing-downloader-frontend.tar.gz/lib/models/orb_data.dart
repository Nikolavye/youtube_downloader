import 'package:flutter/material.dart';

class OrbData {
  final double x;
  final double y;
  final double radius;
  final Color color;
  final double opacity;
  
  const OrbData({
    required this.x,
    required this.y,
    required this.radius,
    required this.color,
    this.opacity = 1.0,
  });
  
  OrbData copyWith({
    double? x,
    double? y,
    double? radius,
    Color? color,
    double? opacity,
  }) {
    return OrbData(
      x: x ?? this.x,
      y: y ?? this.y,
      radius: radius ?? this.radius,
      color: color ?? this.color,
      opacity: opacity ?? this.opacity,
    );
  }
}