import 'package:flutter/material.dart';
import 'dart:math' as math;
import '../models/orb_data.dart';
import '../themes/app_theme.dart';

class HealingBackgroundPainter extends CustomPainter {
  final double animationValue;
  final bool isDark;
  
  const HealingBackgroundPainter({
    required this.animationValue,
    required this.isDark,
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..style = PaintingStyle.fill
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 60);
    
    // 治愈系浮动光球
    final orbs = [
      // 薄荷绿光球
      OrbData(
        x: size.width * 0.2 + math.sin(animationValue * math.pi * 2) * 30,
        y: size.height * 0.3 + math.cos(animationValue * math.pi * 2) * 20,
        radius: 80,
        color: isDark 
          ? AppTheme.healingMint.withOpacity(0.08)
          : AppTheme.healingMint.withOpacity(0.15),
      ),
      
      // 淡紫色光球
      OrbData(
        x: size.width * 0.8 + math.cos(animationValue * math.pi * 2 + 1.5) * 35,
        y: size.height * 0.2 + math.sin(animationValue * math.pi * 2 + 1.5) * 25,
        radius: 100,
        color: isDark
          ? AppTheme.softLavender.withOpacity(0.06)
          : AppTheme.softLavender.withOpacity(0.12),
      ),
      
      // 温暖桃色光球
      OrbData(
        x: size.width * 0.15 + math.sin(animationValue * math.pi * 2 + 2.5) * 25,
        y: size.height * 0.7 + math.cos(animationValue * math.pi * 2 + 2.5) * 30,
        radius: 90,
        color: isDark
          ? AppTheme.gentlePeach.withOpacity(0.05)
          : AppTheme.gentlePeach.withOpacity(0.1),
      ),
      
      // 宁静蓝色光球
      OrbData(
        x: size.width * 0.7 + math.cos(animationValue * math.pi * 2 + 3.5) * 28,
        y: size.height * 0.8 + math.sin(animationValue * math.pi * 2 + 3.5) * 22,
        radius: 70,
        color: isDark
          ? AppTheme.tranquilBlue.withOpacity(0.04)
          : AppTheme.tranquilBlue.withOpacity(0.08),
      ),
      
      // 玫瑰腮红光球
      OrbData(
        x: size.width * 0.5 + math.sin(animationValue * math.pi * 2 + 4.5) * 40,
        y: size.height * 0.15 + math.cos(animationValue * math.pi * 2 + 4.5) * 15,
        radius: 60,
        color: isDark
          ? AppTheme.rosyBlush.withOpacity(0.03)
          : AppTheme.rosyBlush.withOpacity(0.06),
      ),
    ];
    
    // 绘制渐变背景
    final backgroundPaint = Paint()
      ..shader = RadialGradient(
        center: Alignment.topCenter,
        radius: 1.5,
        colors: isDark 
          ? [
              AppTheme.darkBackground,
              AppTheme.darkSurface.withOpacity(0.8),
              AppTheme.darkBackground,
            ]
          : [
              AppTheme.warmCream,
              Colors.white,
              AppTheme.warmCream.withOpacity(0.7),
            ],
        stops: const [0.0, 0.5, 1.0],
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), backgroundPaint);
    
    // 绘制治愈光球
    for (final orb in orbs) {
      paint.color = orb.color;
      canvas.drawCircle(
        Offset(orb.x, orb.y),
        orb.radius,
        paint,
      );
      
      // 添加内部高光效果
      final highlightPaint = Paint()
        ..color = orb.color.withOpacity(orb.color.opacity * 0.3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 20);
      
      canvas.drawCircle(
        Offset(orb.x - orb.radius * 0.3, orb.y - orb.radius * 0.3),
        orb.radius * 0.4,
        highlightPaint,
      );
    }
    
    // 添加星光效果
    _drawStarlight(canvas, size);
  }
  
  void _drawStarlight(Canvas canvas, Size size) {
    final starlightPaint = Paint()
      ..color = isDark 
        ? Colors.white.withOpacity(0.1)
        : AppTheme.primaryMint.withOpacity(0.2)
      ..strokeWidth = 1.0
      ..style = PaintingStyle.stroke;
    
    final random = math.Random(42); // 固定种子保持一致性
    
    for (int i = 0; i < 8; i++) {
      final x = random.nextDouble() * size.width;
      final y = random.nextDouble() * size.height;
      final twinkle = math.sin(animationValue * math.pi * 4 + i) * 0.5 + 0.5;
      
      starlightPaint.color = starlightPaint.color.withOpacity(twinkle * 0.6);
      
      // 绘制十字星光
      canvas.drawLine(
        Offset(x - 3, y),
        Offset(x + 3, y),
        starlightPaint,
      );
      canvas.drawLine(
        Offset(x, y - 3),
        Offset(x, y + 3),
        starlightPaint,
      );
    }
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}