import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'dart:math' as math;

import '../controllers/download_controller.dart';
import '../widgets/healing_header.dart';
import '../widgets/healing_url_input.dart';
import '../widgets/healing_download_button.dart';
import '../painters/healing_background_painter.dart';
import '../themes/app_theme.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final TextEditingController _urlController = TextEditingController();
  late AnimationController _backgroundController;
  late AnimationController _floatingController;
  late Animation<double> _backgroundAnimation;
  late Animation<double> _floatingAnimation;

  @override
  void initState() {
    super.initState();
    
    _backgroundController = AnimationController(
      duration: const Duration(seconds: 30), // 更慢更治愈的背景动画
      vsync: this,
    )..repeat();

    _floatingController = AnimationController(
      duration: const Duration(seconds: 6), // 更慢的浮动
      vsync: this,
    )..repeat(reverse: true);

    _backgroundAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _backgroundController,
      curve: Curves.easeInOut,
    ));

    _floatingAnimation = Tween<double>(
      begin: -5.0,
      end: 5.0,
    ).animate(CurvedAnimation(
      parent: _floatingController,
      curve: Curves.easeInOut,
    ));

    WidgetsBinding.instance.addPostFrameCallback((_) {
      final controller = Provider.of<DownloadController>(context, listen: false);
      controller.initSocket();
      controller.loadFiles();
      controller.checkDownloaderStatus();
    });
  }

  @override
  void dispose() {
    _backgroundController.dispose();
    _floatingController.dispose();
    _urlController.dispose();
    super.dispose();
  }

  Future<void> _startDownload() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      _showMessage('请输入视频链接哦~ 🌸', isError: false);
      return;
    }

    final controller = Provider.of<DownloadController>(context, listen: false);
    final result = await controller.startDownload(url);
    
    if (!result['success']) {
      _showMessage('下载遇到了小问题: ${result['error']} 💭', isError: true);
    } else {
      _showMessage('开始治愈下载啦~ ✨', isError: false);
    }
  }

  void _showMessage(String message, {required bool isError}) {
    final colorScheme = Theme.of(context).colorScheme;
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Container(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: isError 
                    ? Colors.white.withOpacity(0.2)
                    : Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  isError ? Icons.healing_rounded : Icons.auto_awesome_rounded,
                  color: Colors.white,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  message,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
        ),
        backgroundColor: isError 
          ? AppTheme.accentPeach.withOpacity(0.9)
          : AppTheme.primaryMint.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        margin: const EdgeInsets.all(16),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final colorScheme = Theme.of(context).colorScheme;

    return Scaffold(
      backgroundColor: colorScheme.surface,
      body: AnimatedBuilder(
        animation: Listenable.merge([_backgroundAnimation, _floatingAnimation]),
        builder: (context, child) {
          return Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Color.lerp(
                    isDark ? AppTheme.darkBackground : AppTheme.warmCream,
                    isDark ? AppTheme.darkSurface : Colors.white,
                    math.sin(_backgroundAnimation.value * math.pi * 2) * 0.2 + 0.8,
                  )!,
                  Color.lerp(
                    isDark ? AppTheme.darkSurface : Colors.white,
                    isDark ? AppTheme.darkBackground : AppTheme.warmCream,
                    math.cos(_backgroundAnimation.value * math.pi * 2 + 1) * 0.1 + 0.9,
                  )!,
                ],
              ),
            ),
            child: Stack(
              children: [
                // 治愈背景
                Positioned.fill(
                  child: CustomPaint(
                    painter: HealingBackgroundPainter(
                      animationValue: _backgroundAnimation.value,
                      isDark: isDark,
                    ),
                  ),
                ),
                
                // 主要内容
                SafeArea(
                  child: CustomScrollView(
                    physics: const BouncingScrollPhysics(),
                    slivers: [
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.all(24.0),
                          child: Transform.translate(
                            offset: Offset(0, _floatingAnimation.value),
                            child: Column(
                              children: [
                                const SizedBox(height: 20),
                                
                                // 治愈头部
                                const HealingHeader().animate()
                                  .slideY(begin: -0.15, duration: 800.ms, curve: Curves.easeOutCubic)
                                  .fadeIn(),
                                
                                const SizedBox(height: 32),
                                
                                // 主要卡片
                                _buildHealingCard(),
                                
                                const SizedBox(height: 120),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildHealingCard() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: isDark 
          ? LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppTheme.darkSurface.withOpacity(0.9),
                AppTheme.darkSurface.withOpacity(0.7),
              ],
            )
          : const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Colors.white,
                Color(0xFFFFFBF7),
              ],
            ),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(
          color: isDark 
            ? Colors.white.withOpacity(0.08)
            : AppTheme.primaryMint.withOpacity(0.1),
          width: 1,
        ),
        boxShadow: isDark 
          ? [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 40,
                offset: const Offset(0, 16),
              ),
            ]
          : AppTheme.softShadow,
      ),
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // URL输入框
            HealingUrlInput(
              controller: _urlController,
              onSubmit: _startDownload,
            ),
            
            const SizedBox(height: 32),
            
            // 下载类型选择
            _buildTypeSelector(),
            
            const SizedBox(height: 32),
            
            // 下载按钮
            Consumer<DownloadController>(
              builder: (context, controller, child) {
                return HealingDownloadButton(
                  isLoading: controller.isLoading,
                  downloadType: controller.downloadType,
                  onPressed: _startDownload,
                );
              },
            ),
            
            const SizedBox(height: 24),
            
            // 进度显示
            _buildProgressSection(),
          ],
        ),
      ),
    ).animate()
      .slideY(begin: 0.1, duration: 1000.ms, delay: 300.ms, curve: Curves.easeOutCubic)
      .fadeIn();
  }

  Widget _buildTypeSelector() {
    return Consumer<DownloadController>(
      builder: (context, controller, child) {
        final isDark = Theme.of(context).brightness == Brightness.dark;
        
        return Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: isDark 
              ? AppTheme.darkSurface.withOpacity(0.5)
              : AppTheme.healingMint.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: AppTheme.primaryMint.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: _buildTypeOption(
                  'audio',
                  '🎵 音频',
                  '温柔提取',
                  controller.downloadType == 'audio',
                  () => controller.setDownloadType('audio'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildTypeOption(
                  'video',
                  '🎬 视频',
                  '完整保存',
                  controller.downloadType == 'video',
                  () => controller.setDownloadType('video'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildTypeOption(
    String value,
    String title,
    String subtitle,
    bool isSelected,
    VoidCallback onTap,
  ) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
        decoration: BoxDecoration(
          gradient: isSelected 
            ? AppTheme.mintGradient
            : (isDark 
                ? LinearGradient(
                    colors: [
                      Colors.transparent,
                      Colors.transparent,
                    ],
                  )
                : const LinearGradient(
                    colors: [
                      Colors.white,
                      Color(0xFFFAF7F0),
                    ],
                  )),
          borderRadius: BorderRadius.circular(16),
          boxShadow: isSelected 
            ? [
                BoxShadow(
                  color: AppTheme.primaryMint.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ]
            : [],
        ),
        child: Column(
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: isSelected 
                  ? Colors.white
                  : (isDark ? Colors.white : AppTheme.textPrimary),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: isSelected 
                  ? Colors.white.withOpacity(0.8)
                  : (isDark 
                      ? Colors.white.withOpacity(0.6)
                      : AppTheme.textMuted),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressSection() {
    return Consumer<DownloadController>(
      builder: (context, controller, child) {
        if (controller.currentProgress == null) {
          return const SizedBox.shrink();
        }

        final progress = controller.currentProgress!;
        final percentage = (progress['percentage'] ?? 0).toDouble();

        return Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            gradient: AppTheme.healingGradient,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: AppTheme.primaryMint.withOpacity(0.2),
              width: 1,
            ),
          ),
          child: Column(
            children: [
              Text(
                '${percentage.toInt()}%',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.primaryMint,
                ),
              ),
              const SizedBox(height: 16),
              Container(
                height: 8,
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Stack(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 500),
                      width: MediaQuery.of(context).size.width * (percentage / 100),
                      decoration: BoxDecoration(
                        gradient: AppTheme.mintGradient,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ).animate()
          .slideY(begin: 0.1, duration: 500.ms)
          .fadeIn();
      },
    );
  }
}