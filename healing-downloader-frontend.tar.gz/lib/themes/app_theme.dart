import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // 治愈系配色方案
  static const Color healingMint = Color(0xFFB8E6B8);
  static const Color softLavender = Color(0xFFE8D5E8);
  static const Color warmCream = Color(0xFFFAF7F0);
  static const Color gentlePeach = Color(0xFFFFE5CC);
  static const Color tranquilBlue = Color(0xFFD6EAF8);
  static const Color rosyBlush = Color(0xFFFDE2E7);
  
  // 主色调
  static const Color primaryMint = Color(0xFF7FB069);
  static const Color secondaryLavender = Color(0xFFA855F7);
  static const Color accentPeach = Color(0xFFFF8A65);
  static const Color neutralWarm = Color(0xFF8B7355);
  
  // 文字颜色
  static const Color textPrimary = Color(0xFF2D3748);
  static const Color textSecondary = Color(0xFF4A5568);
  static const Color textMuted = Color(0xFF718096);
  
  // 深色模式
  static const Color darkBackground = Color(0xFF1A202C);
  static const Color darkSurface = Color(0xFF2D3748);
  static const Color darkTextPrimary = Color(0xFFE2E8F0);
  
  static ThemeData buildLightTheme() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      textTheme: GoogleFonts.nunitoTextTheme(),
      colorScheme: const ColorScheme.light(
        primary: primaryMint,
        secondary: secondaryLavender,
        tertiary: accentPeach,
        surface: warmCream,
        surfaceVariant: Color(0xFFF5F2EA),
        onPrimary: Colors.white,
        onSecondary: Colors.white,
        onSurface: textPrimary,
        onSurfaceVariant: textSecondary,
        outline: Color(0xFFE2D5C7),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        ),
      ),
    );
  }
  
  static ThemeData buildDarkTheme() {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      textTheme: GoogleFonts.nunitoTextTheme(ThemeData.dark().textTheme),
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFF9ACD97),
        secondary: Color(0xFFB794F6),
        tertiary: Color(0xFFFFB084),
        surface: darkSurface,
        surfaceVariant: Color(0xFF4A5568),
        onPrimary: darkBackground,
        onSecondary: darkBackground,
        onSurface: darkTextPrimary,
        onSurfaceVariant: Color(0xFFCBD5E0),
        outline: Color(0xFF4A5568),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
      ),
    );
  }
  
  // 治愈系渐变
  static const LinearGradient healingGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [
      Color(0xFFF7FAFC),
      Color(0xFFEDF2F7),
      Color(0xFFE2E8F0),
    ],
  );
  
  static const LinearGradient mintGradient = LinearGradient(
    colors: [
      Color(0xFFB8E6B8),
      Color(0xFF7FB069),
    ],
  );
  
  static const LinearGradient lavenderGradient = LinearGradient(
    colors: [
      Color(0xFFE8D5E8),
      Color(0xFFA855F7),
    ],
  );
  
  static const LinearGradient warmGradient = LinearGradient(
    colors: [
      Color(0xFFFFE5CC),
      Color(0xFFFF8A65),
    ],
  );
  
  // 柔和阴影
  static List<BoxShadow> get softShadow => [
    BoxShadow(
      color: Colors.black.withOpacity(0.05),
      blurRadius: 20,
      offset: const Offset(0, 8),
    ),
    BoxShadow(
      color: primaryMint.withOpacity(0.1),
      blurRadius: 40,
      offset: const Offset(0, 16),
    ),
  ];
  
  static List<BoxShadow> get glowShadow => [
    BoxShadow(
      color: primaryMint.withOpacity(0.3),
      blurRadius: 24,
      offset: const Offset(0, 8),
    ),
    BoxShadow(
      color: secondaryLavender.withOpacity(0.2),
      blurRadius: 32,
      offset: const Offset(0, 12),
    ),
  ];
}