import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:video_transcriber/main.dart';

void main() {
  testWidgets('App smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(const MyApp());

    // Verify that the app starts with the correct title.
    expect(find.text('🎬 视频音频下载器'), findsOneWidget);
    
    // Verify that the URL input field exists.
    expect(find.byType(TextField), findsOneWidget);
    
    // Verify that the download button exists.
    expect(find.textContaining('下载'), findsOneWidget);
  });
}